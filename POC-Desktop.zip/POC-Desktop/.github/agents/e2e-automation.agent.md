---
name: "E2E Automation"
description: >
  Unified orchestrator for desktop E2E automation — routes to planner, generator, or healer
  based on the first keyword in the input. Handles the full lifecycle: source scanning →
  test case planning → code generation → execution → healing. Reads e2e-config.json for
  all paths, credentials, and settings. Produces a combined HTML report at the end and
  intermediate reports after each significant step.
tools:
  - read
  - edit
  - execute
  - search
  - todo
model: Claude Sonnet 4.6 (copilot)
user-invocable: true
argument-hint: >
  "<mode> [options]"

  Modes:
    planner  [feature] [app|feature] [positive|negative|both]
    generator [feature] [continue|reset] [tc:<ID>] [stop-after:<ID>]
    healer   [<tc-ids>|all] [locator|step|build|device]
    status                         → show current state summary
    full [feature]                 → run planner → generator (end-to-end)
    report                         → regenerate latest HTML report from state

  Examples:
    "planner"
    "planner BandwidthGauges positive"
    "generator"
    "generator BandwidthGauges tc:TC003"
    "healer all"
    "healer TC005,TC009 locator"
    "status"
    "full BandwidthGauges"
    "report"
---

# E2E Automation Orchestrator

You are **E2E-Automation** — the unified desktop automation orchestrator.
You delegate to the **planner**, **generator**, or **healer** workflow based on the
first keyword in the user input, loading `e2e-config.json` for all configuration.

> Re-discover all paths on every run. Never cache across sessions.

---

## Step 0 — Load Config + Route Input

```powershell
Clear-Host

# ── Load config ─────────────────────────────────────────────────────
$configPath = Join-Path (git rev-parse --show-toplevel 2>$null) ".github\config\e2e-config.json"
if (-not (Test-Path $configPath)) {
    Write-Host @"
╔══════════════════════════════════════════════════════════════════════════╗
║  E2E AUTOMATION — CONFIG NOT FOUND                                      ║
╠══════════════════════════════════════════════════════════════════════════╣
║  e2e-config.json not found at: .github/config/e2e-config.json           ║
║                                                                          ║
║  Create and fill in the config file first:                              ║
║    .github/config/e2e-config.json                                        ║
║                                                                          ║
║  See E2E-README.md for the full field reference.                         ║
╚══════════════════════════════════════════════════════════════════════════╝
"@
    exit 1
}

$cfg = Get-Content $configPath -Raw | ConvertFrom-Json

$repoRoot       = $cfg.repo.sourcePath
$automationRoot = $cfg.repo.automationRootPath  -replace '/', '\'
$existingPath   = $cfg.repo.existingAutomationPath -replace '/', '\'
$stateFilePath  = Join-Path $repoRoot ($cfg.generator.stateFilePath -replace '/', '\')
$reportDir      = Join-Path $repoRoot ($cfg.reporting.outputPath -replace '/', '\')
$themeColor     = if ($cfg.reporting.htmlThemeColor) { $cfg.reporting.htmlThemeColor } else { '#0078d4' }

# ── Parse mode + args ────────────────────────────────────────────────
$rawInput = ($userMessage -replace '^\s*"?|"?\s*$', '').Trim()
$tokens   = $rawInput -split '\s+'
$mode     = if ($tokens.Count -gt 0) { $tokens[0].ToLower() } else { "" }
$modeArgs = ($tokens | Select-Object -Skip 1) -join ' '

# Normalise aliases
$modeMap = @{
    "plan"      = "planner"
    "generate"  = "generator"
    "gen"       = "generator"
    "heal"      = "healer"
    "fix"       = "healer"
    "repair"    = "healer"
    "check"     = "status"
    "state"     = "status"
    "all"       = "full"
    "end-to-end"= "full"
    "e2e"       = "full"
}
if ($modeMap[$mode]) { $mode = $modeMap[$mode] }

$runTs   = Get-Date -Format 'yyyyMMdd_HHmmss'
$orchLog = [System.Collections.Generic.List[string]]::new()

function Add-Log([string]$msg) {
    $e = "[$(Get-Date -Format 'HH:mm:ss')] $msg"; $orchLog.Add($e); Write-Host $e
}

$validModes = @("planner","generator","healer","status","full","report")

# ── Banner ───────────────────────────────────────────────────────────
Write-Host "╔══════════════════════════════════════════════════════════════════════╗"
Write-Host "║  E2E AUTOMATION ORCHESTRATOR                                         ║"
Write-Host "╠══════════════════════════════════════════════════════════════════════╣"
Write-Host "║  Mode   : $($mode.PadRight(62))║"
Write-Host "║  Args   : $($modeArgs.PadRight(62))║"
Write-Host "║  Config : $($configPath.PadRight(62).Substring(0,62))║"
Write-Host "╠══════════════════════════════════════════════════════════════════════╣"
Write-Host "║  Available modes:                                                    ║"
Write-Host "║    planner   [feature] [app|feature] [positive|negative|both]        ║"
Write-Host "║    generator [feature] [continue|reset] [tc:TC001] [stop-after:TC010]║"
Write-Host "║    healer    [all | TC001,TC002,...] [locator|step|build|device]     ║"
Write-Host "║    full      [feature]  ← planner then generator end-to-end         ║"
Write-Host "║    status               ← show state file summary                   ║"
Write-Host "║    report               ← regenerate HTML from current state        ║"
Write-Host "╚══════════════════════════════════════════════════════════════════════╝"

if ($mode -notin $validModes) {
    Write-Host "`n❌ Unknown mode: '$mode'"
    Write-Host "   Valid: planner | generator | healer | full | status | report"
    exit 1
}
Add-Log "🚀 Orchestrator started — mode=$mode args=$modeArgs"
```

---

## STATUS Mode

```powershell
if ($mode -eq "status") {
    Write-Host "`n📊 [STATUS] Current automation state..."

    if (-not (Test-Path $stateFilePath)) {
        Write-Host "   ❌ No state file found at $stateFilePath"
        Write-Host "   Run: e2e-automation generator"
        exit 0
    }

    $state = Get-Content $stateFilePath -Raw | ConvertFrom-Json
    $tcFilePath = Join-Path $repoRoot ($cfg.planning.testCasesPath -replace '/', '\')
    $totalPlanned = 0
    if (Test-Path $tcFilePath) {
        $totalPlanned = (Select-String -Path $tcFilePath -Pattern '^### TC\d+' | Measure-Object).Count
    }

    $pct = if ($totalPlanned -gt 0) { [Math]::Round($state.automatedTCs.Count / $totalPlanned * 100) } else { 0 }

    Write-Host "`n  State file   : $stateFilePath"
    Write-Host "  Last updated : $($state.lastUpdated)"
    Write-Host "  Total planned: $totalPlanned"
    Write-Host "  Automated    : $($state.automatedTCs.Count)  ($pct%)"
    Write-Host "  Failed       : $($state.failedTCs.Count)"
    Write-Host "  Next index   : $($state.nextTCIndex)"
    Write-Host "  Last TC      : $($state.lastProcessedTC)"

    if ($state.automatedTCs.Count -gt 0) {
        Write-Host "`n  ✅ Automated TCs:"
        $state.automatedTCs | ForEach-Object { Write-Host "     $_" }
    }
    if ($state.failedTCs.Count -gt 0) {
        Write-Host "`n  ❌ Failed TCs (run healer):"
        $state.failedTCs | ForEach-Object { Write-Host "     $_" }
        Write-Host "`n  Run: e2e-automation healer all"
    }

    # Progress bar (text)
    $bars   = [Math]::Floor($pct / 5)
    $spaces = 20 - $bars
    $bar    = "  Progress: [" + ("█" * $bars) + ("░" * $spaces) + "] $pct%"
    Write-Host $bar
    Add-Log "✅ STATUS — automated=$($state.automatedTCs.Count)/$totalPlanned failed=$($state.failedTCs.Count)"
    exit 0
}
```

---

## REPORT Mode

```powershell
if ($mode -eq "report") {
    Write-Host "`n📊 [REPORT] Regenerating HTML summary from current state..."

    if (-not (Test-Path $reportDir)) { New-Item $reportDir -ItemType Directory -Force | Out-Null }

    $state = if (Test-Path $stateFilePath) {
        Get-Content $stateFilePath -Raw | ConvertFrom-Json
    } else {
        [PSCustomObject]@{ automatedTCs=@(); failedTCs=@(); lastUpdated="N/A"; nextTCIndex=0 }
    }

    $tcFilePath   = Join-Path $repoRoot ($cfg.planning.testCasesPath -replace '/', '\')
    $totalPlanned = if (Test-Path $tcFilePath) {
        (Select-String -Path $tcFilePath -Pattern '^### TC\d+' | Measure-Object).Count
    } else { 0 }

    $pct     = if ($totalPlanned -gt 0) { [Math]::Round($state.automatedTCs.Count / $totalPlanned * 100) } else { 0 }
    $autoRows= $state.automatedTCs | ForEach-Object { "<tr><td><code>$_</code></td><td><span class='badge pass'>automated</span></td></tr>" }
    $failRows= $state.failedTCs    | ForEach-Object { "<tr><td><code>$_</code></td><td><span class='badge fail'>failed</span></td></tr>" }

    $html = @"
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>E2E Automation — Summary Report $runTs</title>
<style>
  :root{--brand:$themeColor}*{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Segoe UI',Arial,sans-serif;background:#f0f2f5;color:#323130}
  header{background:var(--brand);color:white;padding:24px 32px}
  header h1{font-size:22px;font-weight:600}header p{font-size:13px;opacity:.85;margin-top:4px}
  .container{padding:24px 32px}.stats{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:24px}
  .stat-card{background:white;border-radius:8px;padding:18px 24px;min-width:130px;
             box-shadow:0 1px 4px rgba(0,0,0,.08);text-align:center}
  .stat-card .num{font-size:32px;font-weight:700;color:var(--brand)}
  .stat-card .lbl{font-size:12px;color:#605e5c;margin-top:4px;text-transform:uppercase}
  .stat-card.pass .num{color:#107c10}.stat-card.fail .num{color:#d83b01}
  .card{background:white;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:24px;overflow:hidden}
  .card-header{background:var(--brand);color:white;padding:12px 20px;font-weight:600}
  table{width:100%;border-collapse:collapse;font-size:13px}
  th{background:#f3f2f1;padding:10px 12px;text-align:left;border-bottom:2px solid #edebe9}
  td{padding:8px 12px;border-bottom:1px solid #edebe9}
  code{background:#f3f2f1;padding:2px 5px;border-radius:3px;font-size:12px}
  .badge{display:inline-block;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600}
  .badge.pass{background:#dff6dd;color:#107c10}.badge.fail{background:#fde7e9;color:#d83b01}
  .progress-bar{background:#e1dfdd;border-radius:8px;height:20px;margin:10px 0;overflow:hidden}
  .progress-fill{background:var(--brand);height:20px;display:flex;align-items:center;
                 padding-left:10px;color:white;font-size:12px;font-weight:600;white-space:nowrap}
  footer{text-align:center;padding:24px;color:#605e5c;font-size:12px}
</style></head><body>
<header><h1>🖥 E2E Automation — Summary Report</h1>
<p>Generated: $(Get-Date -Format 'dddd, MMMM dd yyyy — HH:mm:ss') &nbsp;|&nbsp; Last state update: $($state.lastUpdated)</p>
</header>
<div class="container">
  <div class="stats">
    <div class="stat-card"><div class="num">$totalPlanned</div><div class="lbl">Total Planned</div></div>
    <div class="stat-card pass"><div class="num">$($state.automatedTCs.Count)</div><div class="lbl">Automated</div></div>
    <div class="stat-card fail"><div class="num">$($state.failedTCs.Count)</div><div class="lbl">Failed</div></div>
    <div class="stat-card"><div class="num">$pct%</div><div class="lbl">Coverage</div></div>
  </div>
  <div class="card"><div class="card-header">📊 Automation Coverage</div>
  <div style="padding:16px 20px">
    <div class="progress-bar"><div class="progress-fill" style="width:$pct%">$pct% ($($state.automatedTCs.Count)/$totalPlanned)</div></div>
    <p style="font-size:12px;color:#605e5c;margin-top:8px">Next TC index: $($state.nextTCIndex) &nbsp;·&nbsp; Last: $($state.lastProcessedTC)</p>
  </div></div>
  $(if($state.automatedTCs.Count -gt 0){"<div class='card'><div class='card-header'>✅ Automated TCs ($($state.automatedTCs.Count))</div>
  <table><thead><tr><th>TC ID</th><th>Status</th></tr></thead><tbody>$($autoRows -join '')</tbody></table></div>"})
  $(if($state.failedTCs.Count -gt 0){"<div class='card'><div class='card-header' style='background:#d83b01'>❌ Failed TCs ($($state.failedTCs.Count))</div>
  <table><thead><tr><th>TC ID</th><th>Status</th></tr></thead><tbody>$($failRows -join '')</tbody></table>
  <div style='padding:12px 20px;font-size:13px;color:#605e5c'>Run: <code>e2e-automation healer all</code> to attempt auto-fix</div></div>"})
</div>
<footer>E2E Automation Orchestrator &nbsp;·&nbsp; Config: $configPath</footer>
</body></html>
"@
    $reportFile = Join-Path $reportDir "summary-report-$runTs.html"
    $html | Out-File $reportFile -Encoding UTF8
    Write-Host "   ✅ Report: $reportFile"
    Add-Log "✅ REPORT generated: $reportFile"
    exit 0
}
```

---

## PLANNER Mode

```powershell
if ($mode -eq "planner") {
    Write-Host "`n🗂  Delegating to PLANNER with args: '$modeArgs'"
    Add-Log "→ PLANNER mode started"

    # ── Re-use planner logic inline ──────────────────────────────────
    # Parse planner-specific args
    $featureFilter = $null; $groupBy = "feature"; $scenarioType = "both"
    if ($modeArgs -match '\b(app|feature)\b') { $groupBy = $Matches[1].ToLower() }
    if ($modeArgs -match '\b(positive|negative|both)\b') { $scenarioType = $Matches[1].ToLower() }
    $cleaned = $modeArgs -replace '\b(app|feature|positive|negative|both)\b',''-replace '\s+',' '
    if ($cleaned.Trim() -ne '') { $featureFilter = $cleaned.Trim() }

    Write-Host "   Feature: $(if($featureFilter){$featureFilter}else{'ALL'})  GroupBy: $groupBy  Type: $scenarioType"

    # Source discovery
    $appsRoot = if (Test-Path (Join-Path $repoRoot "Apps")) { Join-Path $repoRoot "Apps" } else { $repoRoot }
    $excludePatterns = @("\.feature\.cs$","bin[/\\]","obj[/\\]","\.vs[/\\]","Packages[/\\]","e2e[/\\]","\.git[/\\]")
    $sourceFiles = Get-ChildItem $appsRoot -Recurse -Include "*.xaml","*.cs" -ErrorAction SilentlyContinue |
        Where-Object { -not ($excludePatterns | Where-Object { $_.FullName -match $_ }) }
    if ($featureFilter) {
        $sourceFiles = $sourceFiles | Where-Object { $_.FullName -imatch [regex]::Escape($featureFilter) -or $_.Directory.Name -imatch [regex]::Escape($featureFilter) }
    }

    Write-Host "   Source files: $($sourceFiles.Count)"

    # Extract elements (simplified inline — full extraction in e2e-planner.agent.md)
    $tcCount = 0
    $featureMap = @{}
    foreach ($file in $sourceFiles) {
        $content = Get-Content $file.FullName -Raw -ErrorAction SilentlyContinue
        if (-not $content) { continue }
        $area = $file.Directory.Name
        $ids  = [regex]::Matches($content, '(?:AutomationId|x:Name)\s*=\s*"([^"]{2,80})"') |
            ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique
        if (-not $featureMap[$area]) { $featureMap[$area] = @() }
        $featureMap[$area] += $ids
        $tcCount += $ids.Count
    }

    Write-Host "   Estimated TCs: $tcCount across $($featureMap.Keys.Count) feature(s)"
    Write-Host "   → For full TC plan generation, use: e2e-planner $modeArgs"
    Write-Host "   → Or continue with generator directly if TestCases.md already exists"

    # Check if TestCases.md exists already
    $tcFilePath = Join-Path $repoRoot ($cfg.planning.testCasesPath -replace '/', '\')
    if (Test-Path $tcFilePath) {
        $existing = (Select-String -Path $tcFilePath -Pattern '^### TC\d+' | Measure-Object).Count
        Write-Host "`n   ✅ TestCases.md exists with $existing TCs — ready for generator"
        Write-Host "   Run: e2e-automation generator$(if($featureFilter){' '+$featureFilter})"
    } else {
        Write-Host "`n   ⚠️  TestCases.md not found — run e2e-planner first to generate it"
        Write-Host "   Run: e2e-planner$(if($featureFilter){' '+$featureFilter})"
    }
    Add-Log "✅ PLANNER preview done — $tcCount potential TCs, $($featureMap.Keys.Count) areas"
}
```

---

## GENERATOR Mode

```powershell
if ($mode -eq "generator") {
    Write-Host "`n⚙️  Delegating to GENERATOR with args: '$modeArgs'"
    Add-Log "→ GENERATOR mode started"

    $tcFilePath = Join-Path $repoRoot ($cfg.planning.testCasesPath -replace '/', '\')
    if (-not (Test-Path $tcFilePath)) {
        Write-Host "   ❌ TestCases.md not found at $tcFilePath"
        Write-Host "   Run planner first: e2e-automation planner"
        exit 1
    }

    # Show state
    $state = if (Test-Path $stateFilePath) {
        Get-Content $stateFilePath -Raw | ConvertFrom-Json
    } else { $null }

    $totalPlanned = (Select-String -Path $tcFilePath -Pattern '^### TC\d+' | Measure-Object).Count
    $automated    = if ($state) { $state.automatedTCs.Count } else { 0 }
    $failed       = if ($state) { $state.failedTCs.Count    } else { 0 }
    $nextIdx      = if ($state) { $state.nextTCIndex        } else { 0 }

    Write-Host "`n   TestCases.md : $totalPlanned TCs"
    Write-Host "   Automated    : $automated"
    Write-Host "   Failed       : $failed"
    Write-Host "   Next TC index: $nextIdx"

    if ($modeArgs -imatch '\breset\b') {
        Write-Host "   ♻️  Reset requested — state will be cleared"
    } elseif ($state -and $state.nextTCIndex -ge $totalPlanned) {
        Write-Host "   ✅ All TCs processed!"
        if ($failed -gt 0) {
            Write-Host "   ❌ $failed TCs still failing — run: e2e-automation healer all"
        }
    } else {
        $remaining = $totalPlanned - $automated
        Write-Host "   → $remaining TCs remaining to automate"
        Write-Host "   → The generator will start from TC index $nextIdx"
        if ($modeArgs -imatch '\btc:(TC\d+)\b') {
            Write-Host "   → Override: starting from $($Matches[1])"
        }
    }

    Write-Host "`n   → For full TC-by-TC automation, invoke: e2e-generator $modeArgs"
    Write-Host "      (This orchestrator shows the preview; use e2e-generator for full execution)"
    Add-Log "✅ GENERATOR preview — $automated/$totalPlanned automated, $failed failed"
}
```

---

## HEALER Mode

```powershell
if ($mode -eq "healer") {
    Write-Host "`n🩹 Delegating to HEALER with args: '$modeArgs'"
    Add-Log "→ HEALER mode started"

    $state = if (Test-Path $stateFilePath) {
        Get-Content $stateFilePath -Raw | ConvertFrom-Json
    } else { $null }

    $failedTCs = if ($state) { $state.failedTCs } else { @() }

    if ($modeArgs -imatch '\ball\b') {
        Write-Host "   Targeting ALL failed TCs: $($failedTCs -join ', ')"
    } else {
        $specified = [regex]::Matches($modeArgs, '\b(TC\d+)\b') | ForEach-Object { $_.Groups[1].Value }
        Write-Host "   Targeting: $($specified -join ', ')"
    }

    if ($failedTCs.Count -eq 0 -and $modeArgs -imatch '\ball\b') {
        Write-Host "   ✅ No failed TCs in state — nothing to heal"
    } else {
        Write-Host "`n   → For full heal execution, invoke: e2e-healer $modeArgs"
        Write-Host "      (This orchestrator shows the preview; use e2e-healer for full execution)"
    }
    Add-Log "✅ HEALER preview — $($failedTCs.Count) failed TCs in state"
}
```

---

## FULL Mode (Planner → Generator end-to-end)

```powershell
if ($mode -eq "full") {
    Write-Host "`n🔄 FULL mode — Planner → Generator end-to-end"
    Add-Log "→ FULL mode started"

    $featureFilter = if ($modeArgs.Trim() -ne '') { $modeArgs.Trim() } else { $null }

    # Step A: Check if TestCases.md exists
    $tcFilePath = Join-Path $repoRoot ($cfg.planning.testCasesPath -replace '/', '\')
    if (Test-Path $tcFilePath) {
        $existing = (Select-String -Path $tcFilePath -Pattern '^### TC\d+' | Measure-Object).Count
        Write-Host "   ✅ TestCases.md found with $existing TCs — skipping planner"
        Write-Host "      (Delete $tcFilePath to force re-planning)"
    } else {
        Write-Host "   📋 TestCases.md not found — planner must run first"
        Write-Host "   Run: e2e-planner$(if($featureFilter){' '+$featureFilter})"
        Write-Host "   Then: e2e-automation generator$(if($featureFilter){' '+$featureFilter})"
        Add-Log "⚠️  FULL: TestCases.md missing — planner must run first"
        exit 1
    }

    # Step B: Check state
    $state = if (Test-Path $stateFilePath) { Get-Content $stateFilePath -Raw | ConvertFrom-Json } else { $null }
    $automated = if ($state) { $state.automatedTCs.Count } else { 0 }
    $failed    = if ($state) { $state.failedTCs.Count    } else { 0 }
    $nextIdx   = if ($state) { $state.nextTCIndex        } else { 0 }
    $totalPlanned = (Select-String -Path $tcFilePath -Pattern '^### TC\d+' | Measure-Object).Count

    Write-Host "`n   State: $automated/$totalPlanned automated  |  $failed failed  |  next index: $nextIdx"

    if ($nextIdx -ge $totalPlanned -and $failed -eq 0) {
        Write-Host "   ✅ All TCs already automated — nothing to do"
        Write-Host "   Run: e2e-automation report"
        Add-Log "✅ FULL: All $totalPlanned TCs already done"
    } elseif ($failed -gt 0) {
        Write-Host "`n   ❌ There are $failed failed TCs:"
        $state.failedTCs | ForEach-Object { Write-Host "      $_" }
        Write-Host "`n   Recommended sequence:"
        Write-Host "   1. e2e-automation healer all       → auto-fix failures"
        Write-Host "   2. e2e-automation generator $(if($featureFilter){$featureFilter}else{'continue'})  → continue pending TCs"
    } else {
        Write-Host "`n   Recommended sequence:"
        Write-Host "   1. e2e-generator$(if($featureFilter){' '+$featureFilter}else{''})  → automate TCs interactively"
        Write-Host "   2. e2e-automation report           → view final summary"
    }
    Add-Log "✅ FULL preview complete"
}
```

---

## Combined HTML Report (all modes)

```powershell
# Generate a combined orchestrator report after any mode
if (-not (Test-Path $reportDir)) { New-Item $reportDir -ItemType Directory -Force | Out-Null }

$state = if (Test-Path $stateFilePath) { Get-Content $stateFilePath -Raw | ConvertFrom-Json } else { $null }
$tcFilePath = Join-Path $repoRoot ($cfg.planning.testCasesPath -replace '/', '\')
$totalPlanned = if (Test-Path $tcFilePath) {
    (Select-String -Path $tcFilePath -Pattern '^### TC\d+' | Measure-Object).Count
} else { 0 }

$automated = if ($state) { $state.automatedTCs.Count } else { 0 }
$failed    = if ($state) { $state.failedTCs.Count    } else { 0 }
$pct       = if ($totalPlanned -gt 0) { [Math]::Round($automated / $totalPlanned * 100) } else { 0 }

$recentReports = Get-ChildItem $reportDir -Filter "*.html" -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending | Select-Object -First 6 | ForEach-Object {
        "<li><a href='$($_.Name)'>$($_.Name)</a> &nbsp; <small style='color:#605e5c'>$('{0:dd MMM yyyy HH:mm}' -f $_.LastWriteTime)</small></li>"
    }

$html = @"
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>E2E Automation — Orchestrator Dashboard</title>
  <meta http-equiv="refresh" content="60">
  <style>
    :root{--brand:$themeColor}*{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'Segoe UI',Arial,sans-serif;background:#f0f2f5;color:#323130}
    header{background:var(--brand);color:white;padding:24px 32px}
    header h1{font-size:24px;font-weight:600}header p{font-size:13px;opacity:.85;margin-top:4px}
    .container{padding:24px 32px}
    .stats{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:24px}
    .stat-card{background:white;border-radius:8px;padding:18px 28px;min-width:140px;
               box-shadow:0 1px 4px rgba(0,0,0,.08);text-align:center}
    .stat-card .num{font-size:36px;font-weight:700;color:var(--brand)}
    .stat-card .lbl{font-size:11px;color:#605e5c;margin-top:4px;text-transform:uppercase;letter-spacing:.5px}
    .stat-card.pass .num{color:#107c10}.stat-card.fail .num{color:#d83b01}.stat-card.pct .num{color:#8764b8}
    .card{background:white;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.08);
          margin-bottom:24px;overflow:hidden}
    .card-header{background:var(--brand);color:white;padding:12px 20px;font-weight:600;font-size:14px}
    .card-body{padding:20px}
    .mode-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;padding:20px}
    .mode-card{border:1px solid #edebe9;border-radius:8px;padding:16px;cursor:pointer;
               transition:box-shadow .15s}
    .mode-card:hover{box-shadow:0 2px 8px rgba(0,0,0,.12);border-color:var(--brand)}
    .mode-card h3{font-size:15px;color:var(--brand);margin-bottom:6px}
    .mode-card p{font-size:12px;color:#605e5c;line-height:1.5}
    .mode-card code{background:#f3f2f1;padding:2px 6px;border-radius:3px;font-size:11px;display:block;margin-top:8px}
    .progress-bar{background:#e1dfdd;border-radius:8px;height:24px;overflow:hidden;margin:12px 0}
    .progress-fill{background:var(--brand);height:24px;display:flex;align-items:center;padding:0 12px;
                   color:white;font-size:12px;font-weight:600;min-width:40px;white-space:nowrap}
    code{background:#f3f2f1;padding:2px 5px;border-radius:3px;font-size:12px}
    footer{text-align:center;padding:24px;color:#605e5c;font-size:12px}
    ul{list-style:none;padding:0}li{padding:6px 0;border-bottom:1px solid #edebe9;font-size:13px}
    li:last-child{border-bottom:none}a{color:var(--brand);text-decoration:none}a:hover{text-decoration:underline}
  </style>
</head>
<body>
  <header>
    <h1>🖥 E2E Automation Dashboard</h1>
    <p>Mode: <strong>$mode</strong> &nbsp;|&nbsp;
       Args: $modeArgs &nbsp;|&nbsp;
       $(Get-Date -Format 'dddd, MMMM dd yyyy — HH:mm:ss') &nbsp;|&nbsp;
       Auto-refresh: 60s</p>
  </header>

  <div class="container">
    <div class="stats">
      <div class="stat-card"><div class="num">$totalPlanned</div><div class="lbl">Planned TCs</div></div>
      <div class="stat-card pass"><div class="num">$automated</div><div class="lbl">Automated</div></div>
      <div class="stat-card fail"><div class="num">$failed</div><div class="lbl">Failed</div></div>
      <div class="stat-card pct"><div class="num">$pct%</div><div class="lbl">Coverage</div></div>
    </div>

    <div class="card">
      <div class="card-header">📊 Automation Coverage</div>
      <div class="card-body">
        <div class="progress-bar">
          <div class="progress-fill" style="width:$pct%">$pct% ($automated / $totalPlanned)</div>
        </div>
        <p style="font-size:12px;color:#605e5c">
          $(if($state){"Last updated: $($state.lastUpdated) &nbsp;·&nbsp; Last TC: $($state.lastProcessedTC)"}else{'No state yet'})
        </p>
      </div>
    </div>

    <div class="card">
      <div class="card-header">🚀 Available Modes</div>
      <div class="mode-grid">
        <div class="mode-card">
          <h3>🗂 Planner</h3>
          <p>Scan source code, extract UI elements, generate TestCases.md grouped by feature or app.</p>
          <code>e2e-automation planner [feature]</code>
        </div>
        <div class="mode-card">
          <h3>⚙️ Generator</h3>
          <p>TC-by-TC automation: generate Feature files, PageObjects, StepDefs, build, run, retry.</p>
          <code>e2e-automation generator [feature]</code>
        </div>
        <div class="mode-card">
          <h3>🩹 Healer</h3>
          <p>Diagnose and auto-fix failed TCs: locator, step, build, timeout, device issues.</p>
          <code>e2e-automation healer all</code>
        </div>
        <div class="mode-card">
          <h3>🔄 Full</h3>
          <p>End-to-end: check planner output then run generator. Guides you through the sequence.</p>
          <code>e2e-automation full [feature]</code>
        </div>
        <div class="mode-card">
          <h3>📊 Status</h3>
          <p>Show current automation state: how many TCs done, failed, pending, next index.</p>
          <code>e2e-automation status</code>
        </div>
        <div class="mode-card">
          <h3>📄 Report</h3>
          <p>Regenerate the HTML summary dashboard from the current state file.</p>
          <code>e2e-automation report</code>
        </div>
      </div>
    </div>

    $(if($recentReports) { "<div class='card'><div class='card-header'>📁 Recent Reports</div><div class='card-body'><ul>$($recentReports -join '')</ul></div></div>" })

    <div class="card">
      <div class="card-header">📋 Session Log</div>
      <div class="card-body" style="font-family:monospace;font-size:12px;white-space:pre-wrap;color:#323130">
        $($orchLog -join "`n")
      </div>
    </div>
  </div>

  <footer>E2E Automation Orchestrator &nbsp;·&nbsp; Config: $configPath &nbsp;·&nbsp; Reports: $reportDir</footer>
</body>
</html>
"@

$dashboardFile = Join-Path $reportDir "dashboard-$runTs.html"
$html | Out-File $dashboardFile -Encoding UTF8
Write-Host "`n📊 Dashboard: $dashboardFile"
Add-Log "✅ Dashboard report saved: $dashboardFile"
```

---

## Quick Reference

| Mode | Shorthand | Purpose |
|------|-----------|---------|
| `planner` | `plan` | Scan source → generate `TestCases.md` + HTML report |
| `generator` | `gen`, `generate` | Automate TCs from `TestCases.md` one-by-one |
| `healer` | `heal`, `fix`, `repair` | Diagnose + fix failed TCs |
| `full` | `all`, `e2e`, `end-to-end` | Check planner → guide through full sequence |
| `status` | `check`, `state` | Show state file summary |
| `report` | | Regenerate HTML summary dashboard |

---

## Workflow Guide

```
1. Configure: fill in .github/config/e2e-config.json
2. Plan:      e2e-automation planner          → generates TestCases.md
3. Generate:  e2e-automation generator        → automates TCs one by one
4. Heal:      e2e-automation healer all       → fixes failed TCs (if any)
5. Status:    e2e-automation status           → check progress at any time
6. Report:    e2e-automation report           → view final HTML dashboard
```
