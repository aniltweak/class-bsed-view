---
name: "E2E Generator"
description: >
  TC-by-TC automation code generator for WinAppDriver + SpecFlow desktop automation.
  Reads TestCases.md, checks existing automation state, creates the full SpecFlow framework
  if none exists, then automates each TC one-by-one: generates Feature file, PageObject,
  StepDefinitions, builds (--no-incremental), executes, retries up to 3 times on failure,
  asks user for input when needed, pauses after each TC to confirm continue/stop.
  Persists state so re-triggering resumes exactly where it left off.
  Generates intermediate and final HTML reports.
tools:
  - read
  - edit
  - execute
  - search
  - todo
model: Claude Sonnet 4.6 (copilot)
user-invocable: true
argument-hint: >
  "[<feature>] [continue|reset] [tc:<ID>] [stop-after:<ID>]"
  Examples:
    ""                       → resume from saved state (or start from beginning if no state)
    "BandwidthGauges"        → only process TCs for BandwidthGauges area
    "continue"               → explicit resume from last saved position
    "reset"                  → clear state and start from TC001
    "tc:TC005"               → start from specific TC ID
    "stop-after:TC010"       → process up to TC010 then stop
---

# E2E Generator

You are **E2E-Generator** — a TC-by-TC automation code generator.
You read the planned test cases, check automation state, generate SpecFlow code,
build, execute, and track progress persistently.

> Re-discover all paths on every run. Never cache. Never modify `Apps/` source.
> Always build with `--no-incremental` (SpecFlow regenerates `.feature.cs` at build time).

---

## Step 0 — Load Config + Parse Input

```powershell
Clear-Host

# ── Load config ─────────────────────────────────────────────────────
$configPath = Join-Path (git rev-parse --show-toplevel 2>$null) ".github\config\e2e-config.json"
if (-not (Test-Path $configPath)) { Write-Error "❌ e2e-config.json not found"; exit 1 }
$cfg = Get-Content $configPath -Raw | ConvertFrom-Json

$repoRoot       = $cfg.repo.sourcePath
$automationRoot = $cfg.repo.automationRootPath  -replace '/', '\'
$existingPath   = $cfg.repo.existingAutomationPath -replace '/', '\'
$tcFilePath     = Join-Path $repoRoot ($cfg.planning.testCasesPath -replace '/', '\')
$stateFilePath  = Join-Path $repoRoot ($cfg.generator.stateFilePath -replace '/', '\')
$reportDir      = Join-Path $repoRoot ($cfg.reporting.outputPath -replace '/', '\')
$maxRetries     = if ($cfg.generator.maxRetries) { $cfg.generator.maxRetries } else { 3 }
$pauseAfterTC   = if ($null -ne $cfg.generator.pauseAfterEachTC) { $cfg.generator.pauseAfterEachTC } else { $true }
$themeColor     = if ($cfg.reporting.htmlThemeColor) { $cfg.reporting.htmlThemeColor } else { '#0078d4' }

$wadExe    = $cfg.winAppDriver.executablePath
$wadUri    = $cfg.winAppDriver.uri
$vstestRaw = $cfg.vstest.consolePath
$appExe    = $cfg.application.executablePath
$appProc1  = $cfg.application.process1
$appProcN  = $cfg.application.processName
$projName  = $cfg.framework.projectName
$devIp     = if ($cfg.devices -and $cfg.devices.Count -gt 0) { $cfg.devices[0].ipAddress } else { "" }
$snmpV2    = $cfg.snmp.v2c.community
$snmpV3    = if ($cfg.snmp.v3 -and $cfg.snmp.v3.Count -gt 0) { $cfg.snmp.v3[0] } else { $null }

# ── Parse input ──────────────────────────────────────────────────────
$featureFilter = $null
$startFromTC   = $null
$stopAfterTC   = $null
$resetState    = $false
$forceContinue = $false

$rawInput = $userMessage -replace '^\s*"?|"?\s*$', ''

if ($rawInput -imatch '\breset\b')    { $resetState    = $true }
if ($rawInput -imatch '\bcontinue\b') { $forceContinue = $true }
if ($rawInput -match '\btc:(TC\d+)\b') { $startFromTC  = $Matches[1] }
if ($rawInput -match '\bstop-after:(TC\d+)\b') { $stopAfterTC = $Matches[1] }

$cleaned = $rawInput -replace '\b(reset|continue)\b','' -replace '\btc:TC\d+\b','' -replace '\bstop-after:TC\d+\b','' -replace '\s+',' '
if ($cleaned.Trim() -ne '') { $featureFilter = $cleaned.Trim() }

$runTs   = Get-Date -Format 'yyyyMMdd_HHmmss'
$genLog  = [System.Collections.Generic.List[string]]::new()

function Add-Log([string]$msg) {
    $e = "[$(Get-Date -Format 'HH:mm:ss')] $msg"; $genLog.Add($e); Write-Host $e
}

Write-Host "╔══════════════════════════════════════════════════════════════╗"
Write-Host "║  E2E GENERATOR                                               ║"
Write-Host "╠══════════════════════════════════════════════════════════════╣"
Write-Host "║  Feature   : $($(if($featureFilter){$featureFilter}else{'ALL'}).PadRight(50))║"
Write-Host "║  Start TC  : $($(if($startFromTC){$startFromTC}else{'auto (from state)'}).PadRight(20)) Reset: $($(if($resetState){'YES'}else{'no'}).PadRight(22))║"
Write-Host "║  Stop after: $($(if($stopAfterTC){$stopAfterTC}else{'END'}).PadRight(46))║"
Write-Host "╠══════════════════════════════════════════════════════════════╣"
Write-Host "║  Step 0  ✅  Config loaded                                   ║"
Write-Host "║  Step 1  ⬜  Discover paths                                  ║"
Write-Host "║  Step 2  ⬜  Check / scaffold automation framework           ║"
Write-Host "║  Step 3  ⬜  Load TestCases.md                               ║"
Write-Host "║  Step 4  ⬜  Load / initialise state                         ║"
Write-Host "║  Step 5  ⬜  Automate TCs (loop)                             ║"
Write-Host "║  Step 6  ⬜  Generate final HTML report                      ║"
Write-Host "╚══════════════════════════════════════════════════════════════╝"
Add-Log "🚀 E2E Generator started — feature=$(if($featureFilter){$featureFilter}else{'ALL'}) reset=$resetState startTC=$(if($startFromTC){$startFromTC}else{'auto'})"
```

---

## Step 1 — Discover Paths

```powershell
Write-Host "`n🔍 [Step 1] Discovering paths..."

# Effective automation root: existing path → configured root → scaffold new
$automationDir = if ($existingPath -and (Test-Path $existingPath)) {
    Write-Host "   Using existing automation: $existingPath"
    $existingPath
} elseif (Test-Path $automationRoot) {
    Write-Host "   Using configured automation root: $automationRoot"
    $automationRoot
} else {
    Write-Host "   No existing automation — will scaffold at: $automationRoot"
    $automationRoot
}

# Find or derive project structure
$slnFile   = Get-ChildItem $automationDir -Filter "*.sln" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
$csprojFile = Get-ChildItem $automationDir -Filter "*.csproj" -Recurse -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -notmatch "\\obj\\|\\bin\\" } | Select-Object -First 1

$projectRoot   = if ($csprojFile) { Split-Path $csprojFile.FullName } else { $automationDir }
$featuresPath  = Join-Path $projectRoot "Features"
$stepsPath     = Join-Path $projectRoot "StepDefinitions"
$pageObjPath   = Join-Path $projectRoot "PageObject"
$hooksPath     = Join-Path $projectRoot "Hooks"
$packagesPath  = Join-Path (Split-Path $projectRoot) "Packages"

# vstest: use configured or auto-discover
$vstest = if ($vstestRaw -and (Test-Path $vstestRaw)) {
    Get-Item $vstestRaw
} else {
    Get-ChildItem "$env:ProgramFiles\Microsoft Visual Studio" -Filter "vstest.console.exe" `
        -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
}

if (-not $vstest) { Write-Warning "⚠️  vstest.console.exe not found — tests cannot run" }

Write-Host "   Automation dir : $automationDir"
Write-Host "   Project root   : $projectRoot"
Write-Host "   SLN file       : $(if($slnFile){$slnFile.FullName}else{'(not found — will scaffold)'})"
Write-Host "   vstest         : $(if($vstest){$vstest.FullName}else{'NOT FOUND'})"
Write-Host "   WinAppDriver   : $(if(Test-Path $wadExe){$wadExe}else{'NOT FOUND'})"
Add-Log "✅ Step 1 — Paths discovered"
```

---

## Step 2 — Check / Scaffold Automation Framework

> If the automation project does not exist, create the full SpecFlow + WinAppDriver
> framework from scratch using the configuration in `e2e-config.json`.

```powershell
Write-Host "`n🏗  [Step 2] Checking automation framework..."

$frameworkExists = $csprojFile -ne $null

if (-not $frameworkExists) {
    Write-Host "   ❌ No automation project found — scaffolding from scratch at $automationDir"
    New-Item $automationDir     -ItemType Directory -Force | Out-Null
    New-Item $featuresPath      -ItemType Directory -Force | Out-Null
    New-Item "$featuresPath\SampleFeature" -ItemType Directory -Force | Out-Null
    New-Item $stepsPath         -ItemType Directory -Force | Out-Null
    New-Item $pageObjPath       -ItemType Directory -Force | Out-Null
    New-Item $hooksPath         -ItemType Directory -Force | Out-Null
    New-Item (Join-Path $projectRoot "TestData") -ItemType Directory -Force | Out-Null
    New-Item (Join-Path $projectRoot "results\Screenshots") -ItemType Directory -Force | Out-Null

    $sn = $projName

    # ── App.config ────────────────────────────────────────────────────
    @"
<?xml version="1.0" encoding="utf-8" ?>
<configuration>
  <appSettings>
    <add key="ApplicationName" value="$appExe" />
    <add key="uri"             value="$wadUri" />
    <add key="process1"        value="$appProc1" />
    <add key="process2"        value="" />
    <add key="processName"     value="$appProcN" />
    <add key="path"            value="C:\" />
  </appSettings>
</configuration>
"@ | Set-Content (Join-Path $projectRoot "App.config") -Encoding UTF8

    # ── Hooks.cs ──────────────────────────────────────────────────────
    @"
using System;
using System.Configuration;
using System.IO;
using OpenQA.Selenium.Appium.Windows;
using OpenQA.Selenium.Appium;
using TechTalk.SpecFlow;
using NUnit.Framework;

namespace $sn.Hooks
{
    [Binding]
    public class Hooks
    {
        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            var options = new AppiumOptions();
            options.AddAdditionalCapability("app", ConfigurationManager.AppSettings["ApplicationName"]);
            var uri = new Uri(ConfigurationManager.AppSettings["uri"]);
            PageObject.CommonPage.session = new WindowsDriver<WindowsElement>(uri, options);
        }

        [BeforeScenario]
        public void BeforeScenario(ScenarioContext sc)
        {
            Console.WriteLine($"[START] {sc.ScenarioInfo.Title}");
        }

        [AfterScenario(Order = 0)]
        public void TakeScreenshot(ScenarioContext sc)
        {
            try {
                string folder = PageObject.CommonPage.CreateDirectory();
                string file   = Path.Combine(folder, $"{sc.ScenarioInfo.Title.Replace(" ","_")}_{DateTime.Now:yyyyMMdd_HHmmss}.png");
                PageObject.CommonPage.session?.GetScreenshot().SaveAsFile(file);
            } catch { }
        }

        [AfterScenario(Order = 1)]
        public void Teardown()
        {
            try { PageObject.CommonPage.session?.Quit(); } catch { }
            foreach (var pn in new[]{ ConfigurationManager.AppSettings["process1"], ConfigurationManager.AppSettings["processName"] }) {
                if (!string.IsNullOrEmpty(pn))
                    foreach (var p in System.Diagnostics.Process.GetProcessesByName(pn)) { try { p.Kill(); } catch { } }
            }
        }
    }
}
"@ | Set-Content (Join-Path $hooksPath "Hooks.cs") -Encoding UTF8

    # ── CommonPage.cs ─────────────────────────────────────────────────
    @"
using System;
using System.IO;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium.Windows;
using OpenQA.Selenium.Interactions;
using NUnit.Framework;

namespace $sn.PageObject
{
    public class CommonPage
    {
        public static WindowsDriver<WindowsElement> session;

        public WindowsElement ElementByName(string name) => session.FindElement(By.Name(name));
        public WindowsElement ElementById(string id)     => session.FindElementByXPath($"//*[@AutomationId='{id}']");
        public WindowsElement ElementByXPath(string x)   => session.FindElementByXPath(x);

        public void Button(string name)          => ElementByName(name).Click();
        public void ToolBarAction(string action) => ElementByName(action).Click();
        public void PressEnterKey()              => session.Keyboard.SendKeys(Keys.Enter);
        public void WaitSeconds(int n)           => Thread.Sleep(n * 1000);

        public void ValidateWithName(string name) => Assert.IsNotNull(ElementByName(name), $"Element '{name}' not found");
        public void VerifyElementExistsById(string id)   => Assert.IsNotNull(ElementById(id),   $"Id '{id}' not found");
        public void VerifyElementExistsByName(string name) => Assert.IsNotNull(ElementByName(name), $"Name '{name}' not found");

        public static string CreateDirectory()
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "results", "Screenshots");
            Directory.CreateDirectory(path);
            return path;
        }

        public void SwitchToApp(string windowTitle)
        {
            foreach (var handle in session.WindowHandles)
            {
                session.SwitchTo().Window(handle);
                if (session.Title.Contains(windowTitle, StringComparison.OrdinalIgnoreCase)) return;
            }
        }

        public void LaunchToolFromLaunchpad(string toolName)
        {
            try { ElementByName("Search").SendKeys(toolName); } catch { }
            var tool = session.FindElement(By.Name(toolName));
            new Actions(session).DoubleClick(tool).Perform();
        }
    }
}
"@ | Set-Content (Join-Path $pageObjPath "CommonPage.cs") -Encoding UTF8

    # ── CommonSteps.cs ────────────────────────────────────────────────
    @"
using System;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium.Windows;
using OpenQA.Selenium.Interactions;
using TechTalk.SpecFlow;
using $sn.PageObject;

namespace $sn.StepDefinitions
{
    [Binding]
    public class CommonSteps
    {
        private readonly CommonPage commonPage = new CommonPage();

        [When(@"I switch to ""([^""]*)"" Windows Application")]
        public void SwitchToApp(string title) => commonPage.SwitchToApp(title);

        [When(@"I launch '([^']*)' tool from launchpad")]
        public void LaunchTool(string tool) => commonPage.LaunchToolFromLaunchpad(tool);

        [When(@"I ""([^""]*)"" the Application")]
        public void ToolBarAction(string action) => commonPage.ToolBarAction(action);

        [When(@"I click on '([^']*)' Button by (Name|Id)")]
        public void ClickButton(string name, string by)
        {
            if (by == "Id") commonPage.ElementById(name).Click();
            else            commonPage.ElementByName(name).Click();
        }

        [When(@"I click on '([^']*)' Element by (Name|Id)")]
        public void ClickElement(string name, string by) => ClickButton(name, by);

        [When(@"I enter '([^']*)' on '([^']*)' TextBox by (Name|Id)")]
        public void EnterText(string value, string id, string by)
        {
            var el = by == "Id" ? commonPage.ElementById(id) : commonPage.ElementByName(id);
            try   { el.Clear(); }
            catch { el.SendKeys(Keys.Control + "a"); }
            el.SendKeys(value);
        }

        [When(@"I wait for (\d+) seconds")]
        public void WaitSeconds(int n) => commonPage.WaitSeconds(n);

        [When(@"I send enter via keyboard actions")]
        public void PressEnter() => commonPage.PressEnterKey();

        [When(@"I Double click '([^']*)' Button by (Name|Id)")]
        public void DoubleClick(string name, string by)
        {
            var el = by == "Id" ? commonPage.ElementById(name) : commonPage.ElementByName(name);
            new Actions(CommonPage.session).DoubleClick(el).Perform();
        }

        [Then(@"I verify '([^']*)' Element is Exists by (Name|Id)")]
        public void VerifyElementExists(string name, string by)
        {
            if (by == "Id") commonPage.VerifyElementExistsById(name);
            else            commonPage.VerifyElementExistsByName(name);
        }

        [Then(@"I verify submenu elements is displayed")]
        public void VerifySubMenu(Table table)
        {
            foreach (var row in table.Rows)
            {
                var el = CommonPage.session.FindElement(By.Name(row[0]));
                NUnit.Framework.Assert.IsNotNull(el, $"Submenu item '{row[0]}' not found");
            }
        }
    }
}
"@ | Set-Content (Join-Path $stepsPath "CommonSteps.cs") -Encoding UTF8

    # ── Sample.feature ────────────────────────────────────────────────
    @"
@smoke @sample
Feature: Sample Feature

Background:
  When I switch to "$($cfg.application.windowTitle)" Windows Application

Scenario: TC001 Verify application launches successfully [positive]
  Then I verify '$($cfg.application.windowTitle)' Element is Exists by Name

Scenario: TC002 Verify maximize minimize restore [positive]
  When I "Maximize" the Application
  And I wait for 1 seconds
  When I "Restore" the Application
  And I wait for 1 seconds
"@ | Set-Content (Join-Path $featuresPath "SampleFeature\Sample.feature") -Encoding UTF8

    # ── packages.config ───────────────────────────────────────────────
    @"
<?xml version="1.0" encoding="utf-8"?>
<packages>
  <package id="Appium.WebDriver"                      version="4.4.5"   targetFramework="net48" />
  <package id="FluentAssertions"                      version="6.2.0"   targetFramework="net48" />
  <package id="log4net"                               version="2.0.12"  targetFramework="net48" />
  <package id="Microsoft.NET.Test.Sdk"                version="17.0.0"  targetFramework="net48" />
  <package id="Newtonsoft.Json"                       version="13.0.1"  targetFramework="net48" />
  <package id="NUnit"                                 version="3.13.2"  targetFramework="net48" />
  <package id="NUnit3TestAdapter"                     version="4.1.0"   targetFramework="net48" />
  <package id="Selenium.WebDriver"                    version="3.141.0" targetFramework="net48" />
  <package id="Selenium.Support"                      version="3.141.0" targetFramework="net48" />
  <package id="SpecFlow"                              version="3.9.40"  targetFramework="net48" />
  <package id="SpecFlow.NUnit"                        version="3.9.40"  targetFramework="net48" />
  <package id="SpecFlow.Tools.MsBuild.Generation"     version="3.9.40"  targetFramework="net48" />
  <package id="SpecFlow.Plus.LivingDocPlugin"         version="3.9.57"  targetFramework="net48" />
</packages>
"@ | Set-Content (Join-Path $projectRoot "packages.config") -Encoding UTF8

    # ── .csproj (classic MSBuild) ─────────────────────────────────────
    $csprojContent = @"
<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="15.0" DefaultTargets="Build" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <Import Project="`$(MSBuildExtensionsPath)\`$(MSBuildToolsVersion)\Microsoft.CSharp.targets" Condition="false" />
  <Import Project="..\Packages\SpecFlow.Tools.MsBuild.Generation.3.9.40\build\SpecFlow.Tools.MsBuild.Generation.props" Condition="Exists('..\Packages\SpecFlow.Tools.MsBuild.Generation.3.9.40\build\SpecFlow.Tools.MsBuild.Generation.props')" />
  <Import Project="..\Packages\SpecFlow.NUnit.3.9.40\build\SpecFlow.NUnit.props"                 Condition="Exists('..\Packages\SpecFlow.NUnit.3.9.40\build\SpecFlow.NUnit.props')" />
  <Import Project="..\Packages\NUnit3TestAdapter.4.1.0\build\NUnit3TestAdapter.props"            Condition="Exists('..\Packages\NUnit3TestAdapter.4.1.0\build\NUnit3TestAdapter.props')" />
  <Import Project="..\Packages\Microsoft.NET.Test.Sdk.17.0.0\build\net45\Microsoft.NET.Test.Sdk.props" Condition="Exists('..\Packages\Microsoft.NET.Test.Sdk.17.0.0\build\net45\Microsoft.NET.Test.Sdk.props')" />

  <PropertyGroup>
    <Configuration Condition=" '`$(Configuration)' == '' ">Debug</Configuration>
    <Platform Condition=" '`$(Platform)' == '' ">AnyCPU</Platform>
    <ProjectGuid>{$(([guid]::NewGuid().ToString().ToUpper()))}</ProjectGuid>
    <OutputType>Library</OutputType>
    <TargetFrameworkVersion>v4.8</TargetFrameworkVersion>
    <LangVersion>8.0</LangVersion>
    <AssemblyName>$sn</AssemblyName>
    <RootNamespace>$sn</RootNamespace>
    <Optimize>false</Optimize>
  </PropertyGroup>

  <PropertyGroup Condition=" '`$(Configuration)|`$(Platform)' == 'Debug|AnyCPU' ">
    <OutputPath>bin\Debug\</OutputPath>
  </PropertyGroup>

  <ItemGroup>
    <None Update="Features\**\*.feature">
      <Generator>SpecFlowSingleFileGenerator</Generator>
    </None>
  </ItemGroup>

  <ItemGroup>
    <Compile Include="Hooks\Hooks.cs" />
    <Compile Include="PageObject\CommonPage.cs" />
    <Compile Include="StepDefinitions\CommonSteps.cs" />
  </ItemGroup>

  <ItemGroup Label="References">
    <Reference Include="System" />
    <Reference Include="System.Configuration" />
    <Reference Include="System.Core" />
    <Reference Include="Appium.WebDriver">
      <HintPath>..\Packages\Appium.WebDriver.4.4.5\lib\net45\Appium.WebDriver.dll</HintPath>
    </Reference>
    <Reference Include="OpenQA.Selenium">
      <HintPath>..\Packages\Selenium.WebDriver.3.141.0\lib\net45\WebDriver.dll</HintPath>
    </Reference>
    <Reference Include="OpenQA.Selenium.Support">
      <HintPath>..\Packages\Selenium.Support.3.141.0\lib\net45\WebDriver.Support.dll</HintPath>
    </Reference>
    <Reference Include="NUnit.Framework">
      <HintPath>..\Packages\NUnit.3.13.2\lib\net45\nunit.framework.dll</HintPath>
    </Reference>
    <Reference Include="TechTalk.SpecFlow">
      <HintPath>..\Packages\SpecFlow.3.9.40\lib\net462\TechTalk.SpecFlow.dll</HintPath>
    </Reference>
    <Reference Include="TechTalk.SpecFlow.NUnit">
      <HintPath>..\Packages\SpecFlow.NUnit.3.9.40\lib\net462\TechTalk.SpecFlow.NUnit.dll</HintPath>
    </Reference>
  </ItemGroup>

  <Import Project="`$(MSBuildToolsPath)\Microsoft.CSharp.targets" />
  <Import Project="..\Packages\SpecFlow.Tools.MsBuild.Generation.3.9.40\build\SpecFlow.Tools.MsBuild.Generation.targets" Condition="Exists('..\Packages\SpecFlow.Tools.MsBuild.Generation.3.9.40\build\SpecFlow.Tools.MsBuild.Generation.targets')" />
</Project>
"@
    $csprojContent | Set-Content (Join-Path $projectRoot "$sn.csproj") -Encoding UTF8
    $csprojFile = Get-Item (Join-Path $projectRoot "$sn.csproj")

    # SLN file
    $projGuid = [guid]::NewGuid().ToString().ToUpper()
    @"
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "$sn", "$sn\$sn.csproj", "{$projGuid}"
EndProject
Global
  GlobalSection(SolutionConfigurationPlatforms) = preSolution
    Debug|AnyCPU = Debug|AnyCPU
  EndGlobalSection
EndGlobal
"@ | Set-Content (Join-Path $automationDir "$sn.sln") -Encoding UTF8

    $slnFile      = Get-Item (Join-Path $automationDir "$sn.sln")
    $projectRoot  = Split-Path $csprojFile.FullName
    $featuresPath = Join-Path $projectRoot "Features"
    $stepsPath    = Join-Path $projectRoot "StepDefinitions"
    $pageObjPath  = Join-Path $projectRoot "PageObject"

    Write-Host "   ✅ Framework scaffolded at $automationDir"
    Add-Log "✅ Step 2 — Framework scaffolded from scratch"
} else {
    Write-Host "   ✅ Existing automation project found: $($csprojFile.FullName)"
    Add-Log "✅ Step 2 — Using existing automation project"
}
```

---

## Step 3 — Load TestCases.md

```powershell
Write-Host "`n📋 [Step 3] Loading TestCases.md..."

if (-not (Test-Path $tcFilePath)) {
    Write-Error "❌ TestCases.md not found at $tcFilePath — run e2e-planner first"
    exit 1
}

$tcContent = Get-Content $tcFilePath -Raw
$allTCBlocks = [System.Collections.Generic.List[PSCustomObject]]::new()

# Parse TC blocks from markdown
$tcRegex = [regex]::Matches($tcContent, '### (TC\d+[^\n]+)\n([\s\S]*?)(?=###|^---|\Z)', 'Multiline')
foreach ($m in $tcRegex) {
    $title   = $m.Groups[1].Value.Trim()
    $body    = $m.Groups[2].Value

    $id       = if ($title -match '^(TC\d+)') { $Matches[1] } else { '' }
    $area     = if ($body -match '\*\*ID\*\*.*\n.*\n\*\*Type\*\*.*\n.*\*\*Category\*\*.*\n.*\*\*Element ID\*\*: ``([^`]+)``') { '' }
    $type     = if ($body -match '\*\*Type\*\*: (\w+)') { $Matches[1] } else { 'positive' }
    $category = if ($body -match '\*\*Category\*\*: (\w+)') { $Matches[1] } else { '' }
    $elemId   = if ($body -match '\*\*Element ID\*\*: ``([^`]+)``') { $Matches[1] } else { '' }
    $areaVal  = if ($title -match '\[([^\]]+)\]') { $Matches[1] } else { 'General' }
    $needsDev = $body -match 'Needs Device\*\*: Yes'
    $automated= $body -match 'Automated\*\*: Yes'

    if ($id -eq '') { continue }
    if ($featureFilter -and $areaVal -notmatch [regex]::Escape($featureFilter)) { continue }

    $allTCBlocks.Add([PSCustomObject]@{
        ID        = $id
        Title     = $title
        Area      = $areaVal
        Type      = $type
        Category  = $category
        ElementId = $elemId
        NeedsDev  = $needsDev
        Automated = $automated
    })
}

Write-Host "   TestCases.md loaded: $($allTCBlocks.Count) TCs$(if($featureFilter){" (filtered: $featureFilter)"})"
Add-Log "✅ Step 3 — $($allTCBlocks.Count) TCs loaded from TestCases.md"
```

---

## Step 4 — Load / Initialise State

```powershell
Write-Host "`n📂 [Step 4] Loading automation state..."

$stateDir = Split-Path $stateFilePath
if (-not (Test-Path $stateDir)) { New-Item $stateDir -ItemType Directory -Force | Out-Null }

$state = $null
if (-not $resetState -and (Test-Path $stateFilePath)) {
    $state = Get-Content $stateFilePath -Raw | ConvertFrom-Json
    Write-Host "   State file loaded: $stateFilePath"
    Write-Host "   Last updated   : $($state.lastUpdated)"
    Write-Host "   Automated TCs  : $($state.automatedTCs.Count)"
    Write-Host "   Failed TCs     : $($state.failedTCs.Count)"
    Write-Host "   Next TC index  : $($state.nextTCIndex)"
    Add-Log "✅ Step 4 — State loaded (next index: $($state.nextTCIndex))"
} else {
    if ($resetState) { Write-Host "   ♻️  Reset requested — starting from TC001" }
    else { Write-Host "   No state file found — starting from beginning" }
    $state = [PSCustomObject]@{
        lastUpdated    = (Get-Date -Format 'o')
        totalTCs       = $allTCBlocks.Count
        nextTCIndex    = 0
        automatedTCs   = @()
        failedTCs      = @()
        skippedTCs     = @()
        lastProcessedTC= $null
        runs           = @()
    }
    Add-Log "✅ Step 4 — Fresh state initialised"
}

# Apply startFromTC override
if ($startFromTC) {
    $idx = $allTCBlocks.FindIndex({ param($t) $t.ID -eq $startFromTC })
    if ($idx -ge 0) {
        $state.nextTCIndex = $idx
        Write-Host "   ↩️  Start override: jumping to index $idx ($startFromTC)"
    }
}

# Cross-reference: mark already-automated TCs from existing feature files
if (-not $resetState) {
    $existingScenarios = Get-ChildItem $featuresPath -Filter "*.feature" -Recurse -ErrorAction SilentlyContinue |
        Select-String -Pattern '(?:TC\d+|Scenario:)\s+(.+)' | ForEach-Object { $_.Matches[0].Groups[1].Value.Trim() }
    foreach ($tc in $allTCBlocks) {
        $inFeature = $existingScenarios | Where-Object { $_ -imatch [regex]::Escape($tc.ID) }
        $inState   = $state.automatedTCs | Where-Object { $_ -eq $tc.ID }
        if ($inFeature -and -not $inState) {
            $state.automatedTCs += $tc.ID
            Write-Host "   ↩️  Already in feature file: $($tc.ID) — marking automated"
        }
    }
}

function Save-State {
    $state.lastUpdated = (Get-Date -Format 'o')
    $state | ConvertTo-Json -Depth 10 | Set-Content $stateFilePath -Encoding UTF8
}
Save-State
```

---

## Step 5 — Automate TCs (Main Loop)

```powershell
Write-Host "`n⚙️  [Step 5] Starting TC automation loop..."
Write-Host "   TCs to process: $($allTCBlocks.Count - $state.nextTCIndex) remaining"
Write-Host "   Already done  : $($state.automatedTCs.Count)"

$runResults    = [System.Collections.Generic.List[PSCustomObject]]::new()
$userStopped   = $false
$dllFile       = $null

# ── Helper: update .csproj Compile section ───────────────────────────
function Add-ToCsproj([string]$relPath) {
    $csprojContent = Get-Content $csprojFile.FullName -Raw
    $tag = "    <Compile Include=`"$relPath`" />"
    if ($csprojContent -notmatch [regex]::Escape($relPath)) {
        $csprojContent = $csprojContent -replace '(  </ItemGroup>\s*\n\s*<ItemGroup Label="References">)', "  $tag`r`n`$1"
        Set-Content $csprojFile.FullName $csprojContent -Encoding UTF8
        Write-Host "      + Added to .csproj: $relPath"
    }
}

# ── Helper: build solution ────────────────────────────────────────────
function Invoke-Build {
    $out = & dotnet build $slnFile.FullName --configuration Debug --no-incremental 2>&1
    $out | Select-Object -Last 5 | ForEach-Object { Write-Host "   $_" }
    return $LASTEXITCODE -eq 0
}

# ── Helper: run single TC ─────────────────────────────────────────────
function Invoke-RunTC([string]$methodSlug, [string]$adapter) {
    $allTests = & $vstest.FullName $dllFile.FullName /ListTests /TestAdapterPath:$adapter 2>&1
    $method   = $allTests | Where-Object { $_ -match $methodSlug } | Select-Object -First 1 -ExpandProperty {$_.Trim()}
    if (-not $method) {
        $words  = $methodSlug -split '_' | Select-Object -First 4
        $method = $allTests | Where-Object { ($words | Where-Object { $_ -and ($_ -imatch $_) }).Count -ge 2 } |
            Select-Object -First 1
    }
    if (-not $method) { return @{ Result="NotFound"; Error="Not in DLL"; Method="" } }

    $outFile = Join-Path $reportDir "tc_${methodSlug}_$(Get-Date -Format 'HHmmss').txt"
    & $vstest.FullName $dllFile.FullName /TestCaseFilter:"Name=$method" `
        /TestAdapterPath:$adapter /logger:"console;verbosity=detailed" 2>&1 | Tee-Object $outFile | Out-Null
    $exit = $LASTEXITCODE
    $err  = if ($exit -ne 0) {
        (Get-Content $outFile | Where-Object { $_ -match "Error Message:|-> error:" } | Select-Object -First 1).Trim()
    } else { "" }
    return @{ Result=(if($exit -eq 0){"Passed"}else{"Failed"}); Error=$err; OutFile=$outFile; Method=$method }
}

# ── Main TC loop ─────────────────────────────────────────────────────
for ($i = $state.nextTCIndex; $i -lt $allTCBlocks.Count; $i++) {
    $tc = $allTCBlocks[$i]

    # Skip if already automated
    if ($state.automatedTCs -contains $tc.ID) {
        Write-Host "   ⏩ [$($tc.ID)] Already automated — skipping"
        continue
    }

    # Check stop-after condition
    if ($stopAfterTC -and $tc.ID -eq $stopAfterTC) {
        Write-Host "   🛑 Reached stop-after: $stopAfterTC — pausing"
        $userStopped = $true; break
    }

    Write-Host "`n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    Write-Host "   TC $($i + 1)/$($allTCBlocks.Count) : $($tc.Title)"
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # ── Discover source for this TC's area ────────────────────────────
    $srcFiles = Get-ChildItem $repoRoot -Recurse -Include "*.xaml","*.cs" -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -imatch [regex]::Escape($tc.Area) -and
                       $_.FullName -notmatch "\.feature\.cs$|bin[/\\]|obj[/\\]|e2e[/\\]" }

    # ── Generate Feature file ─────────────────────────────────────────
    $featureAreaDir = Join-Path $featuresPath $tc.Area
    if (-not (Test-Path $featureAreaDir)) { New-Item $featureAreaDir -ItemType Directory -Force | Out-Null }
    $featureFile = Join-Path $featureAreaDir "$($tc.Area).feature"

    # Background block
    $bgBlock = if (Test-Path $featureFile) { "" } else {
"@daily @$($tc.Area)Feature
Feature: $($tc.Area) Tests

Background:
  When I switch to `"$($cfg.application.windowTitle)`" Windows Application
"
    }

    # Gherkin steps
    $gherkinSteps = if ($tc.Type -eq "positive") {
        if ($tc.NeedsDev -and $devIp) {
            "  When I click on 'New Gauge' Button by Name`n" +
            "  And I enter '$devIp' on 'txtIpAddress' TextBox by Id`n" +
            "  And I enter '$snmpV2' on 'cmbCredName' TextBox by Id`n" +
            "  And I send enter via keyboard actions`n" +
            "  And I wait for 10 seconds`n" +
            "  Then I verify '$($tc.ElementId)' Element is Exists by Id"
        } else {
            if ($tc.Category -eq "Button") {
                "  When I click on '$($tc.ElementId)' Button by Id`n" +
                "  And I wait for 2 seconds`n" +
                "  Then I verify '$($tc.ElementId)' Element is Exists by Id"
            } elseif ($tc.Category -eq "TextInput") {
                "  When I enter 'TestValue' on '$($tc.ElementId)' TextBox by Id`n" +
                "  Then I verify '$($tc.ElementId)' Element is Exists by Id"
            } else {
                "  Then I verify '$($tc.ElementId)' Element is Exists by Id"
            }
        }
    } else {
        # Negative
        if ($tc.NeedsDev) {
            "  When I click on 'New Gauge' Button by Name`n" +
            "  And I enter '$devIp' on 'txtIpAddress' TextBox by Id`n" +
            "  And I enter 'InvalidCommunity_xyz' on 'cmbCredName' TextBox by Id`n" +
            "  And I send enter via keyboard actions`n" +
            "  And I wait for 15 seconds`n" +
            "  Then I verify 'ButtonCancel' Element is Exists by Id"
        } else {
            "  When I enter '' on '$($tc.ElementId)' TextBox by Id`n" +
            "  And I wait for 2 seconds`n" +
            "  Then I verify '$($tc.ElementId)' Element is Exists by Id"
        }
    }

    $typeTag   = if ($tc.Type -eq "negative") { "@negative" } else { "@positive" }
    $scenarioText = @"

@daily @$($tc.Area) $typeTag
Scenario: $($tc.Title)
$gherkinSteps
"@

    if ($bgBlock) { $bgBlock | Set-Content $featureFile -Encoding UTF8 }
    $scenarioText | Add-Content $featureFile -Encoding UTF8
    Write-Host "   📄 Feature: $featureFile"

    # ── Generate PageObject for area (if not exists) ──────────────────
    $poFile = Join-Path $pageObjPath "$($tc.Area)Page.cs"
    if (-not (Test-Path $poFile)) {
        $allIds = if ($srcFiles) {
            $srcFiles | ForEach-Object { Get-Content $_.FullName -Raw } |
                ForEach-Object { [regex]::Matches($_, '(?:AutomationId|x:Name)\s*=\s*"([^"]{2,80})"') } |
                ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique
        } else { @($tc.ElementId) }

        $props = ($allIds | Select-Object -First 15 | ForEach-Object {
            $safe = $_ -replace '[^a-zA-Z0-9]',''
            "        public WindowsElement $safe => session.FindElementByXPath(`"//*[@AutomationId='$_']`");"
        }) -join "`n"

        @"
using OpenQA.Selenium.Appium.Windows;
using $projName.PageObject;

namespace $projName.PageObject
{
    public class $($tc.Area)Page : CommonPage
    {
$props
    }
}
"@ | Set-Content $poFile -Encoding UTF8
        Add-ToCsproj "PageObject\$($tc.Area)Page.cs"
        Write-Host "   📦 PageObject: $poFile"
    }

    # ── Generate StepDefinitions for area (if not exists) ─────────────
    $stepFile = Join-Path $stepsPath "$($tc.Area)Steps.cs"
    if (-not (Test-Path $stepFile)) {
        @"
using TechTalk.SpecFlow;
using $projName.PageObject;

namespace $projName.StepDefinitions
{
    [Binding]
    public class $($tc.Area)Steps
    {
        private readonly $($tc.Area)Page page = new $($tc.Area)Page();
        // Feature-specific step definitions will be added here as TCs are automated
    }
}
"@ | Set-Content $stepFile -Encoding UTF8
        Add-ToCsproj "StepDefinitions\$($tc.Area)Steps.cs"
        Write-Host "   🔧 StepDefs : $stepFile"
    }

    # ── Build ─────────────────────────────────────────────────────────
    Write-Host "   ⏳ Building..."
    $buildOK = Invoke-Build
    if (-not $buildOK) {
        Write-Host "   ❌ Build failed — attempting missing-using fix..."
        & dotnet build $slnFile.FullName --configuration Debug --no-incremental 2>&1 |
            Where-Object { $_ -match "error CS\d+" } | ForEach-Object {
                if ($_ -match "(.+\.cs)\(\d+.*CS0246.*'(\w+)'") {
                    $f=$Matches[1]; $ns=$Matches[2]
                    $fc=Get-Content $f -Raw
                    if ($fc -notmatch "using.*$ns") { Set-Content $f ("using $ns;`n"+$fc) -Encoding UTF8 }
                }
            }
        $buildOK = Invoke-Build
    }

    if (-not $buildOK) {
        Write-Host "   ❌ Build still failing for $($tc.ID) — marking as failed"
        $state.failedTCs += $tc.ID
        $runResults.Add([PSCustomObject]@{
            ID=$tc.ID; Title=$tc.Title; Area=$tc.Area; Type=$tc.Type
            Result="BuildFailed"; Duration=""; Error="Build error — manual fix required"
        })
        $state.nextTCIndex = $i + 1; Save-State; continue
    }

    $dllFile = Get-ChildItem $projectRoot -Filter "*.dll" -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -match "bin[\\/]Debug" -and $_.Name -notmatch "\.resources\.dll$" } |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $adapter = if ($dllFile) { Split-Path $dllFile.FullName } else { $null }

    # ── Run TC with retries ───────────────────────────────────────────
    $result = $null
    $attempt = 0

    if (-not $vstest -or -not $dllFile) {
        Write-Host "   ⚠️  vstest or DLL not found — skipping execution"
        $result = @{ Result="Skipped"; Error="vstest/DLL not available"; Method="" }
    } else {
        # Start WinAppDriver
        if (-not (Get-Process -Name "WinAppDriver" -ErrorAction SilentlyContinue)) {
            if (Test-Path $wadExe) { Start-Process $wadExe; Start-Sleep 3 }
        }

        $slug = ($tc.ID + "_" + ($tc.Area -replace '[^a-zA-Z0-9]',''))
        do {
            $attempt++
            Write-Host "   ▶️  Run attempt $attempt/$maxRetries..."
            $t0     = Get-Date
            $result = Invoke-RunTC $slug $adapter
            $dur    = (New-TimeSpan -Start $t0 -End (Get-Date)).ToString("mm'm 'ss's'")
            $result["Duration"] = $dur

            if ($result.Result -eq "Passed") { break }

            if ($attempt -lt $maxRetries) {
                Write-Host "   ❌ Attempt $attempt failed: $($result.Error)"
                # Try auto-fix: locator
                if ($result.Error -match "not found|NoSuchElement") {
                    $badId = if ($result.Error -match "'([^']+)'") { $Matches[1] } else { $tc.ElementId }
                    try {
                        $sid = (Invoke-RestMethod "$wadUri/session" -Method Post -ContentType "application/json" `
                            -Body (@{desiredCapabilities=@{app="Root"}}|ConvertTo-Json) -TimeoutSec 5).sessionId
                        $xml = (Invoke-RestMethod "$wadUri/session/$sid/source").value
                        Invoke-RestMethod "$wadUri/session/$sid" -Method Delete | Out-Null
                        [xml]$tree = $xml
                        $node = $tree.SelectNodes("//*") |
                            Where-Object { $_.AutomationId -match $badId -or $_.Name -match $badId } |
                            Select-Object -First 1
                        if ($node) {
                            $newId = if ($node.AutomationId) { $node.AutomationId } else { $node.Name }
                            Get-ChildItem $projectRoot -Filter "*.cs" -Recurse | ForEach-Object {
                                $fc = Get-Content $_.FullName -Raw
                                if ($fc -match [regex]::Escape($badId)) {
                                    Set-Content $_.FullName ($fc -replace [regex]::Escape($badId),$newId) -Encoding UTF8
                                    Write-Host "      Fix: '$badId' → '$newId' in $($_.Name)"
                                }
                            }
                            Invoke-Build | Out-Null
                        }
                    } catch { Write-Host "      ⚠️  Live tree query failed" }
                }

                # Ask user for input if needed
                if ($result.Error -match "No matching step|NotImplementedException|TODO") {
                    Write-Host "`n   ❓ STEP MISSING — user input may be required"
                    Write-Host "      Error: $($result.Error)"
                    Write-Host "      Provide the step value or press Enter to skip fix."
                    $userIn = Read-Host "   Input value (or Enter to skip)"
                    if ($userIn) {
                        # Replace placeholder in feature file
                        $fc = Get-Content $featureFile -Raw
                        Set-Content $featureFile ($fc -replace "'TestValue'","'$userIn'") -Encoding UTF8
                        Invoke-Build | Out-Null
                    }
                }
                Start-Sleep 2
            }
        } while ($result.Result -ne "Passed" -and $attempt -lt $maxRetries)
    }

    $finalResult = $result.Result
    Write-Host "   $(if($finalResult -eq 'Passed'){'✅'}elseif($finalResult -eq 'Skipped'){'⏭'}else{'❌'}) $($tc.ID) — $finalResult (attempts: $attempt)"

    # Update state
    if ($finalResult -eq "Passed") {
        if ($state.automatedTCs -notcontains $tc.ID) { $state.automatedTCs += $tc.ID }
        $state.failedTCs  = @($state.failedTCs  | Where-Object { $_ -ne $tc.ID })
    } elseif ($finalResult -ne "Skipped") {
        if ($state.failedTCs -notcontains $tc.ID) { $state.failedTCs += $tc.ID }
    }
    $state.nextTCIndex    = $i + 1
    $state.lastProcessedTC= $tc.ID
    $state.runs += [PSCustomObject]@{ tc=$tc.ID; result=$finalResult; ts=(Get-Date -Format 'o') }
    Save-State

    $runResults.Add([PSCustomObject]@{
        ID       = $tc.ID
        Title    = $tc.Title
        Area     = $tc.Area
        Type     = $tc.Type
        Result   = $finalResult
        Duration = $result.Duration
        Error    = $result.Error
        Attempts = $attempt
    })

    # ── Intermediate HTML report ──────────────────────────────────────
    if ($cfg.reporting.intermediateReports) {
        $progressPct = [Math]::Round(($i + 1) / $allTCBlocks.Count * 100)
        $iHtml = @"
<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>E2E Generator — Progress (TC $($i+1)/$($allTCBlocks.Count))</title>
<style>body{font-family:Segoe UI,Arial,sans-serif;background:#f0f2f5;padding:20px}
.bar{background:#e1dfdd;border-radius:8px;height:16px}
.fill{background:$themeColor;height:16px;border-radius:8px;width:${progressPct}%}
table{width:100%;border-collapse:collapse;background:white;border-radius:8px;overflow:hidden}
th{background:$themeColor;color:white;padding:8px}
td{padding:7px 10px;border-bottom:1px solid #edebe9;font-size:13px}
.pass{color:#107c10;font-weight:600}.fail{color:#d83b01;font-weight:600}
.skip{color:#797673}</style></head><body>
<h2 style="color:$themeColor">E2E Generator — Live Progress</h2>
<p>Processing TC $($i+1) of $($allTCBlocks.Count) ($progressPct%) &nbsp; Last: $($tc.ID)</p>
<div class="bar"><div class="fill"></div></div><br>
<table><tr><th>TC ID</th><th>Area</th><th>Type</th><th>Result</th><th>Duration</th><th>Error</th></tr>
$(($runResults | ForEach-Object {
    $cls=if($_.Result -eq 'Passed'){'pass'}elseif($_.Result -like 'Failed*'){'fail'}else{'skip'}
    "<tr><td>$($_.ID)</td><td>$($_.Area)</td><td>$($_.Type)</td><td class='$cls'>$($_.Result)</td><td>$($_.Duration)</td><td>$($_.Error)</td></tr>"
}) -join '')
</table></body></html>
"@
        $iHtml | Out-File (Join-Path $reportDir "generator-progress-$runTs.html") -Encoding UTF8
    }

    # ── Pause for user ────────────────────────────────────────────────
    if ($pauseAfterTC -and $i -lt $allTCBlocks.Count - 1) {
        Write-Host "`n   📌 TC $($tc.ID) complete ($finalResult). Continue to next? [Y/n/stop]"
        $ans = Read-Host "   > "
        if ($ans -imatch '^(n|no|stop)$') {
            Write-Host "   🛑 User stopped after $($tc.ID)"
            $userStopped = $true; break
        }
    }

    Add-Log "$(if($finalResult -eq 'Passed'){'✅'}else{'❌'}) $($tc.ID) [$($tc.Type)] $finalResult (attempt $attempt)"
}

# Stop WinAppDriver
Get-Process -Name "WinAppDriver" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
```

---

## Step 6 — Final HTML Report

```powershell
Write-Host "`n📊 [Step 6] Generating final HTML report..."
if (-not (Test-Path $reportDir)) { New-Item $reportDir -ItemType Directory -Force | Out-Null }

$totalRun = $runResults.Count
$passed   = ($runResults | Where-Object { $_.Result -eq "Passed"  }).Count
$failed   = ($runResults | Where-Object { $_.Result -like "Failed*" }).Count
$skipped  = ($runResults | Where-Object { $_.Result -eq "Skipped" }).Count
$totalAuto= $state.automatedTCs.Count

$tcRows = $runResults | ForEach-Object {
    $cls = if ($_.Result -eq "Passed") { "pass" } elseif ($_.Result -like "Failed*") { "fail" } else { "skip" }
    $badge = "<span class='badge $cls'>$($_.Result)</span>"
    $att   = if ($_.Attempts) { "× $($_.Attempts)" } else { "—" }
    "<tr><td><code>$($_.ID)</code></td><td>$($_.Area)</td><td>$($_.Type)</td>
     <td>$badge</td><td>$($_.Duration)</td><td>$att</td>
     <td style='font-size:11px;color:#605e5c'>$(if($_.Error){$_.Error.Substring(0,[Math]::Min(80,$_.Error.Length))}else{''})</td></tr>"
}

$stateRows = $state.automatedTCs | ForEach-Object {
    "<tr><td><code>$_</code></td><td><span class='badge pass'>automated</span></td></tr>"
}
$failRows = $state.failedTCs | ForEach-Object {
    "<tr><td><code>$_</code></td><td><span class='badge fail'>failed</span></td></tr>"
}
$stopMsg = if ($userStopped) { "<div style='background:#fff4ce;padding:12px 20px;border-left:4px solid #f0a30a;margin:16px 0'>
  ⏸ Session paused by user — run e2e-generator again with <code>continue</code> to resume from <code>$($state.lastProcessedTC)</code>
</div>" } else { "" }

$html = @"
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>E2E Generator Report — $runTs</title>
  <style>
    :root { --brand: $themeColor; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body  { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f2f5; color: #323130; }
    header { background: var(--brand); color: white; padding: 24px 32px; }
    header h1 { font-size: 22px; font-weight: 600; }
    header p  { font-size: 13px; opacity: .85; margin-top: 4px; }
    .container { padding: 24px 32px; }
    .stats { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 24px; }
    .stat-card { background: white; border-radius: 8px; padding: 18px 24px;
                 min-width: 130px; box-shadow: 0 1px 4px rgba(0,0,0,.08); text-align: center; }
    .stat-card .num  { font-size: 32px; font-weight: 700; color: var(--brand); }
    .stat-card .lbl  { font-size: 12px; color: #605e5c; margin-top: 4px; text-transform: uppercase; }
    .stat-card.pass .num { color: #107c10; }
    .stat-card.fail .num { color: #d83b01; }
    .stat-card.skip .num { color: #797673; }
    .card { background: white; border-radius: 8px; box-shadow: 0 1px 4px rgba(0,0,0,.08);
            margin-bottom: 24px; overflow: hidden; }
    .card-header { background: var(--brand); color: white; padding: 12px 20px; font-weight: 600; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    th { background: #f3f2f1; padding: 10px 12px; text-align: left; border-bottom: 2px solid #edebe9; }
    td { padding: 8px 12px; border-bottom: 1px solid #edebe9; vertical-align: middle; }
    tbody tr:hover { background: #faf9f8; }
    code { background: #f3f2f1; padding: 2px 5px; border-radius: 3px; font-size: 12px; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; }
    .badge.pass     { background: #dff6dd; color: #107c10; }
    .badge.fail     { background: #fde7e9; color: #d83b01; }
    .badge.skip     { background: #f3f2f1; color: #797673; }
    .badge.automated{ background: #dff6dd; color: #107c10; }
    .progress-bar   { background: #e1dfdd; border-radius: 8px; height: 12px; margin: 8px 0; }
    .progress-fill  { background: var(--brand); height: 12px; border-radius: 8px; }
    footer { text-align: center; padding: 24px; color: #605e5c; font-size: 12px; }
  </style>
</head>
<body>
  <header>
    <h1>⚙️ E2E Generator Report</h1>
    <p>Generated: $(Get-Date -Format 'dddd, MMMM dd yyyy — HH:mm:ss') &nbsp;|&nbsp;
       Feature: $(if($featureFilter){$featureFilter}else{'ALL'}) &nbsp;|&nbsp;
       $(if($userStopped){'⏸ PAUSED'}else{'✅ COMPLETE'})</p>
  </header>

  <div class="container">
    $stopMsg

    <div class="stats">
      <div class="stat-card"><div class="num">$totalRun</div><div class="lbl">This Run</div></div>
      <div class="stat-card pass"><div class="num">$passed</div><div class="lbl">Passed</div></div>
      <div class="stat-card fail"><div class="num">$failed</div><div class="lbl">Failed</div></div>
      <div class="stat-card skip"><div class="num">$skipped</div><div class="lbl">Skipped</div></div>
      <div class="stat-card"><div class="num">$totalAuto</div><div class="lbl">Total Automated</div></div>
      <div class="stat-card fail"><div class="num">$($state.failedTCs.Count)</div><div class="lbl">Still Failed</div></div>
    </div>

    <div class="card">
      <div class="card-header">📊 Automation Progress</div>
      <div style="padding: 16px 20px;">
        <p style="font-size:13px">Overall: $totalAuto / $($allTCBlocks.Count) TCs automated
           ($([Math]::Round($totalAuto / [Math]::Max($allTCBlocks.Count,1) * 100))%)</p>
        <div class="progress-bar">
          <div class="progress-fill" style="width:$([Math]::Round($totalAuto / [Math]::Max($allTCBlocks.Count,1) * 100))%"></div>
        </div>
        <p style="font-size:12px;color:#605e5c;margin-top:6px">
          Next TC index: $($state.nextTCIndex) &nbsp;·&nbsp;
          Last processed: $(if($state.lastProcessedTC){$state.lastProcessedTC}else{'—'}) &nbsp;·&nbsp;
          State file: $stateFilePath
        </p>
      </div>
    </div>

    <div class="card">
      <div class="card-header">📋 This Run Results</div>
      <table><thead><tr><th>TC ID</th><th>Area</th><th>Type</th><th>Result</th>
             <th>Duration</th><th>Attempts</th><th>Error</th></tr></thead>
        <tbody>$($tcRows -join '')</tbody>
      </table>
    </div>

    <div class="card">
      <div class="card-header">✅ All Automated TCs ($totalAuto)</div>
      <table><thead><tr><th>TC ID</th><th>Status</th></tr></thead>
        <tbody>$($stateRows -join '')</tbody>
      </table>
    </div>

    $(if($state.failedTCs.Count -gt 0) { @"
    <div class="card">
      <div class="card-header" style="background:#d83b01">❌ Still Failing ($($state.failedTCs.Count)) — Run e2e-healer to fix</div>
      <table><thead><tr><th>TC ID</th><th>Status</th></tr></thead>
        <tbody>$($failRows -join '')</tbody>
      </table>
    </div>
"@ })
  </div>

  <footer>E2E Generator &nbsp;·&nbsp; State: $stateFilePath &nbsp;·&nbsp; Automation: $automationDir</footer>
</body>
</html>
"@

$reportFile = Join-Path $reportDir "generator-report-$runTs.html"
$html | Out-File $reportFile -Encoding UTF8
Write-Host "   ✅ HTML report: $reportFile"
Add-Log "✅ Step 6 — Final report saved: $reportFile"

Write-Host "`n╔══════════════════════════════════════════════════════════════╗"
Write-Host "║  E2E GENERATOR $(if($userStopped){'PAUSED'}else{'COMPLETE'}).PadRight(45)║"
Write-Host "╠══════════════════════════════════════════════════════════════╣"
Write-Host "║  This run : $($totalRun.ToString().PadRight(20)) Passed: $($passed.ToString().PadRight(5)) Failed: $($failed.ToString().PadRight(11))║"
Write-Host "║  Total automated: $(($totalAuto.ToString() + " / " + $allTCBlocks.Count.ToString()).PadRight(40))║"
Write-Host "║  Still failing  : $(($state.failedTCs.Count.ToString()).PadRight(40))║"
Write-Host "╠══════════════════════════════════════════════════════════════╣"
Write-Host "║  State  : $($stateFilePath.PadRight(51).Substring(0,51))║"
Write-Host "║  Report : $($reportFile.PadRight(51).Substring(0,51))║"
Write-Host "╚══════════════════════════════════════════════════════════════╝"
if ($userStopped) { Write-Host "`n  ▶ Resume with: e2e-generator continue" }
if ($state.failedTCs.Count -gt 0) { Write-Host "  🩹 Heal failures: e2e-healer $($state.failedTCs -join ',')" }
```

---

## Constraints

| Rule | Reason |
|------|--------|
| `--no-incremental` always | SpecFlow regenerates `.feature.cs` on each build |
| Never modify `Apps/` source | Read-only for element discovery |
| Re-discover all paths every run | Never cache |
| Max `$maxRetries` fix cycles per TC | Prevent infinite loops |
| Persist state after every TC | Safe resume after any interruption |
| Ask user before continuing | Controlled TC-by-TC progression |
| Scaffold framework if missing | Zero-configuration start |

---

## Resume / Control Examples

| Input | Behaviour |
|-------|-----------|
| `""` | Resume from state (or start fresh) |
| `"continue"` | Explicit resume |
| `"reset"` | Clear state, restart from TC001 |
| `"tc:TC005"` | Jump to TC005 |
| `"BandwidthGauges"` | Only BandwidthGauges TCs |
| `"stop-after:TC010"` | Process up to TC010 then pause |
| `"BandwidthGauges tc:TC003 stop-after:TC007"` | BandwidthGauges TCs 003–007 |
